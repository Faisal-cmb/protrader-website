function handleLogin(event) {

  event.preventDefault();

  alert("Login functionality coming soon!");

}